// Service worker de Educación Financiera
// 1) Cachea el "app shell" para que la PWA abra aunque no haya conexión.
// 2) Escucha eventos push del navegador y muestra la notificación,
//    incluso si la app no está abierta — esto SÍ es un push real,
//    pero requiere que un backend lo dispare (ver README.md).

const CACHE_NAME = "educacion-financiera-v1";
const APP_SHELL = [
  "./",
  "./index.html",
  "./manifest.json",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// Estrategia: red primero, con respaldo en caché (para que veas gastos
// nuevos si hay internet, pero la app siga abriendo sin conexión).
self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  event.respondWith(
    fetch(event.request)
      .then((response) => {
        const copy = response.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
        return response;
      })
      .catch(() => caches.match(event.request))
  );
});

// Notificación push real: se dispara aunque la app esté cerrada,
// SIEMPRE que un servidor backend haya enviado el push (ver README.md).
self.addEventListener("push", (event) => {
  let data = { title: "Recordatorio de pago", body: "Tienes un pago próximo a vencer." };
  if (event.data) {
    try { data = event.data.json(); } catch (e) { data.body = event.data.text(); }
  }
  event.waitUntil(
    self.registration.showNotification(data.title || "Educación Financiera", {
      body: data.body || "",
      icon: "./icons/icon-192.png",
      badge: "./icons/icon-192.png",
      tag: data.tag || "recordatorio",
    })
  );
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: "window" }).then((clientList) => {
      for (const client of clientList) {
        if ("focus" in client) return client.focus();
      }
      if (self.clients.openWindow) return self.clients.openWindow("./index.html");
    })
  );
});
