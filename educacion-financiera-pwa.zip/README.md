# Educación Financiera — PWA

Esta carpeta convierte la app en una **Progressive Web App (PWA)**: instalable en el
celular con su propio ícono, pantalla completa (sin barra del navegador), y con
soporte para notificaciones push reales.

## Qué incluye

- `index.html` — la app completa (React cargado desde CDN vía import maps, sin necesidad de `npm install` ni build).
- `manifest.json` — nombre, ícono y colores de la app instalada.
- `service-worker.js` — permite abrir la app sin conexión y recibir notificaciones push, incluso con la app cerrada.
- `icons/` — íconos en los tamaños que piden iOS y Android.

## Cómo probarla ahora mismo

No necesitas instalar nada. Desde esta misma carpeta:

```bash
python3 -m http.server 8080
```

Y abre `http://localhost:8080` en tu celular (en la misma red Wi-Fi) o en tu computadora.
**Los navegadores exigen HTTPS para instalar la PWA y usar notificaciones push**
(excepto en `localhost`), así que para probarla de verdad en tu celular necesitas
subirla a un hosting real (siguiente paso).

## Cómo publicarla de verdad (gratis)

Cualquiera de estas opciones sirve, ya que la carpeta es 100% estática (no necesita servidor propio para funcionar como app):

- **Netlify** (netlify.com) — arrastra la carpeta a "Deploys" y listo.
- **Vercel** (vercel.com) — conecta un repositorio o sube la carpeta.
- **GitHub Pages** — sube la carpeta a un repositorio y actívalo en Settings → Pages.

Una vez publicada con HTTPS, entra desde el celular:
- **Android (Chrome)**: aparece un botón "Instalar app" o "Agregar a pantalla de inicio".
- **iPhone (Safari)**: toca compartir → "Agregar a pantalla de inicio".

## Sobre las notificaciones push reales

El `service-worker.js` ya sabe **recibir y mostrar** una notificación push, incluso
con la app cerrada — eso es real. La otra mitad, el backend que **envía** el push,
ya está construido — está en la carpeta `backend/` que viene junto a esta.
Sigue las instrucciones de `backend/README.md` para desplegarlo (gratis, en Render)
y conectarlo con esta PWA.


## Limitaciones de este prototipo

- Los datos (gastos, metas, recordatorios) solo existen mientras el navegador
  tenga la pestaña o la app abierta — se pierden al cerrar, porque no hay una
  base de datos real detrás todavía.
- El envío de notificaciones push (la parte del servidor) no está incluido — solo
  la parte que las recibe y las muestra.
