# Backend de notificaciones — Educación Financiera

Este servidor hace la parte que le faltaba a la PWA: **enviar** las notificaciones
push (la PWA ya sabía recibirlas). Revisa cada minuto si algún recordatorio de
pago venció, y si es así, le manda un push real al navegador del usuario —
funciona aunque la app esté cerrada.

## Antes de empezar: ya tienes las llaves listas

Ya generé un par de llaves VAPID (necesarias para el protocolo de notificaciones push)
para que no tengas que hacerlo tú:

```
VAPID_PUBLIC_KEY=BDSsvrfKsjFIkpVxrhmVSPp_baDZu9mi4mBPDg8clF_A6UAF_SpxjwM1JfFRH0bHS43e5ArgmX9s_GcV0pr_eyk
VAPID_PRIVATE_KEY=YWEuUPaliLQjIYXRVbmrXHsOm6afqOzNX6lHOasHge4
```

La clave **pública** ya está pegada en `index.html` de la PWA (la constante `PUSH_CONFIG.vapidPublicKey`),
así que no tienes que tocarla ahí. La clave **privada** es secreta — nunca la pongas en el
frontend, solo en el backend (paso 3 de abajo).

Si en algún momento quieres generar tu propio par (por ejemplo, para producción real),
corre `node generate-vapid-keys.js` y actualiza ambos lados.

## Paso 1: Sube esta carpeta a GitHub

Necesitas un repositorio (puede ser privado) con estos 3 archivos:
`server.js`, `package.json`, `generate-vapid-keys.js`.

Si nunca has usado GitHub, la forma más fácil desde el navegador:
1. Ve a [github.com/new](https://github.com/new), crea un repositorio (ej. `educacion-financiera-backend`)
2. En la página del repo, "Add file" → "Upload files", y arrastra los 3 archivos

## Paso 2: Despliega en Render (gratis)

[Render](https://render.com) tiene un plan gratuito que sirve perfecto para esto.

1. Crea una cuenta en render.com (puedes entrar con tu cuenta de GitHub)
2. "New" → "Web Service"
3. Conecta el repositorio que acabas de subir
4. Configuración:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Instance Type:** Free
5. En la sección **Environment**, agrega estas dos variables:
   - `VAPID_PUBLIC_KEY` = `BDSsvrfKsjFIkpVxrhmVSPp_baDZu9mi4mBPDg8clF_A6UAF_SpxjwM1JfFRH0bHS43e5ArgmX9s_GcV0pr_eyk`
   - `VAPID_PRIVATE_KEY` = `YWEuUPaliLQjIYXRVbmrXHsOm6afqOzNX6lHOasHge4`
6. Click "Create Web Service" — Render te da una URL como `https://tu-app.onrender.com`

## Paso 3: Conecta la PWA con tu backend

Abre `index.html` de la PWA, busca esta línea (cerca del principio del script):

```js
const PUSH_CONFIG = {
  apiBase: "", // Ej: "https://tu-backend.onrender.com"
  ...
```

Pega ahí la URL que te dio Render:

```js
const PUSH_CONFIG = {
  apiBase: "https://tu-app.onrender.com",
  ...
```

Guarda, y vuelve a subir la carpeta actualizada a Netlify (arrastrando el zip otra vez).

## Verificación real de correo y teléfono (opcional)

Además de las notificaciones push, este backend también puede enviar el
**código de verificación real** por correo (con [Resend](https://resend.com))
o por SMS (con [Twilio](https://twilio.com)) cuando alguien inicia sesión.
Si no configuras esto, la app sigue funcionando en modo de prueba (muestra
el código en pantalla en vez de enviarlo).

### Correo con Resend (gratis hasta 3,000 correos/mes)

1. Crea una cuenta en [resend.com](https://resend.com)
2. Verifica un dominio propio (o usa el de pruebas que te dan al inicio, solo funciona para enviarte a ti mismo)
3. Copia tu API Key
4. Agrega estas variables en Render:
   - `RESEND_API_KEY` = tu llave
   - `RESEND_FROM_EMAIL` = ej. `Educación Financiera <codigo@tudominio.com>`

### SMS con Twilio (de pago, unos centavos por SMS)

1. Crea una cuenta en [twilio.com](https://twilio.com) y agrega saldo
2. Compra o activa un número de Twilio para enviar SMS
3. Copia tu Account SID y Auth Token desde el dashboard
4. Agrega estas variables en Render:
   - `TWILIO_ACCOUNT_SID` = tu SID
   - `TWILIO_AUTH_TOKEN` = tu token
   - `TWILIO_FROM_NUMBER` = tu número de Twilio, formato `+15017122661`

**Importante sobre Twilio:** a diferencia de las notificaciones push (gratis) y
Resend (gratis hasta cierto límite), **Twilio cobra por cada SMS enviado**. Si
solo quieres probar la app, activa nada más Resend (correo) y deja el login
por teléfono en modo de prueba.

## Cómo probarlo

1. Abre la PWA instalada, entra a **Recordatorios**, activa las notificaciones
2. Agrega un recordatorio con fecha de **hoy**
3. Cierra la app por completo (no solo minimizarla)
4. Espera hasta un minuto — debería llegarte la notificación aunque la app esté cerrada

## Nota sobre el plan gratuito de Render

El plan gratuito "duerme" el servidor después de un rato sin uso, y tarda unos
segundos en despertar con la primera visita. Para este caso (revisar recordatorios
cada minuto) igual funciona, porque el propio servidor se mantiene corriendo solo
mientras tenga al menos un usuario con recordatorios pendientes activos — pero si
notas que deja de revisar después de mucha inactividad total, es justamente por eso.
Para algo más confiable a largo plazo, el siguiente paso sería un plan pagado
(Render, Railway, Fly.io) que no duerma el servicio.
